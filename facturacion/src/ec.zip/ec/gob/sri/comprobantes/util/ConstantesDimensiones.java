/*    */ package ec.gob.sri.comprobantes.util;
/*    */ 
/*    */ public class ConstantesDimensiones
/*    */ {
/* 12 */   public static final Integer LONGITUD_CEDULA = Integer.valueOf(10);
/* 13 */   public static final Integer LONGITUD_RUC = Integer.valueOf(13);
/* 14 */   public static final Integer LONGITUD_PASAPORTE = Integer.valueOf(13);
/* 15 */   public static final Integer LONGITUD_TELEFONO = Integer.valueOf(15);
/* 16 */   public static final Integer LONGITUD_CELULAR = Integer.valueOf(10);
/* 17 */   public static final Integer LONGITUD_EXTENSION = Integer.valueOf(6);
/* 18 */   public static final Integer LONGITUD_SECUENCIAS = Integer.valueOf(9);
/*    */ }

/* Location:           C:\prolan\ce\ComprobantesDesktop.jar
 * Qualified Name:     ec.gob.sri.comprobantes.util.ConstantesDimensiones
 * JD-Core Version:    0.6.2
 */