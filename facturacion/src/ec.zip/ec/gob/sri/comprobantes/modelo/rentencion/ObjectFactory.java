/*    */ package ec.gob.sri.comprobantes.modelo.rentencion;
/*    */ 
/*    */ import ec.gob.sri.comprobantes.modelo.InfoTributaria;
/*    */ import javax.xml.bind.annotation.XmlRegistry;
/*    */ 
/*    */ @XmlRegistry
/*    */ public class ObjectFactory
/*    */ {
/*    */   public ComprobanteRetencion.InfoAdicional createComprobanteRetencionInfoAdicional()
/*    */   {
/* 45 */     return new ComprobanteRetencion.InfoAdicional();
/*    */   }
/*    */ 
/*    */   public ComprobanteRetencion.Impuestos createComprobanteRetencionImpuestos()
/*    */   {
/* 53 */     return new ComprobanteRetencion.Impuestos();
/*    */   }
/*    */ 
/*    */   public ComprobanteRetencion.InfoCompRetencion createComprobanteRetencionInfoCompRetencion()
/*    */   {
/* 61 */     return new ComprobanteRetencion.InfoCompRetencion();
/*    */   }
/*    */ 
/*    */   public ComprobanteRetencion.InfoAdicional.CampoAdicional createComprobanteRetencionInfoAdicionalCampoAdicional()
/*    */   {
/* 69 */     return new ComprobanteRetencion.InfoAdicional.CampoAdicional();
/*    */   }
/*    */ 
/*    */   public InfoTributaria createInfoTributaria()
/*    */   {
/* 77 */     return new InfoTributaria();
/*    */   }
/*    */ 
/*    */   public ComprobanteRetencion createComprobanteRetencion()
/*    */   {
/* 85 */     return new ComprobanteRetencion();
/*    */   }
/*    */ 
/*    */   public Impuesto createImpuesto()
/*    */   {
/* 93 */     return new Impuesto();
/*    */   }
/*    */ }

/* Location:           C:\prolan\ce\ComprobantesDesktop.jar
 * Qualified Name:     ec.gob.sri.comprobantes.modelo.rentencion.ObjectFactory
 * JD-Core Version:    0.6.2
 */