/*    */ package ec.gob.sri.comprobantes.modelo.reportes;
/*    */ 
/*    */ public class DetalleGuiaReporte
/*    */ {
/*    */   private String cantidad;
/*    */   private String descripcion;
/*    */   private String codigoPrincipal;
/*    */   private String codigoAuxiliar;
/*    */ 
/*    */   public String getCantidad()
/*    */   {
/* 21 */     return this.cantidad;
/*    */   }
/*    */ 
/*    */   public void setCantidad(String cantidad)
/*    */   {
/* 28 */     this.cantidad = cantidad;
/*    */   }
/*    */ 
/*    */   public String getDescripcion()
/*    */   {
/* 35 */     return this.descripcion;
/*    */   }
/*    */ 
/*    */   public void setDescripcion(String descripcion)
/*    */   {
/* 42 */     this.descripcion = descripcion;
/*    */   }
/*    */ 
/*    */   public String getCodigoPrincipal()
/*    */   {
/* 49 */     return this.codigoPrincipal;
/*    */   }
/*    */ 
/*    */   public void setCodigoPrincipal(String codigoPrincipal)
/*    */   {
/* 56 */     this.codigoPrincipal = codigoPrincipal;
/*    */   }
/*    */ 
/*    */   public String getCodigoAuxiliar()
/*    */   {
/* 63 */     return this.codigoAuxiliar;
/*    */   }
/*    */ 
/*    */   public void setCodigoAuxiliar(String codigoAuxiliar)
/*    */   {
/* 70 */     this.codigoAuxiliar = codigoAuxiliar;
/*    */   }
/*    */ }

/* Location:           C:\prolan\ce\ComprobantesDesktop.jar
 * Qualified Name:     ec.gob.sri.comprobantes.modelo.reportes.DetalleGuiaReporte
 * JD-Core Version:    0.6.2
 */