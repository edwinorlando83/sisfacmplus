/*    */ package ec.gob.sri.comprobantes.modelo.reportes;
/*    */ 
/*    */ public class InformacionAdicional
/*    */ {
/*    */   private String valor;
/*    */   private String nombre;
/*    */ 
/*    */   public InformacionAdicional(String valor, String nombre)
/*    */   {
/* 16 */     this.valor = valor;
/* 17 */     this.nombre = nombre;
/*    */   }
/*    */ 
/*    */   public InformacionAdicional()
/*    */   {
/*    */   }
/*    */ 
/*    */   public String getValor()
/*    */   {
/* 29 */     return this.valor;
/*    */   }
/*    */ 
/*    */   public void setValor(String valor)
/*    */   {
/* 36 */     this.valor = valor;
/*    */   }
/*    */ 
/*    */   public String getNombre()
/*    */   {
/* 43 */     return this.nombre;
/*    */   }
/*    */ 
/*    */   public void setNombre(String nombre)
/*    */   {
/* 50 */     this.nombre = nombre;
/*    */   }
/*    */ }

/* Location:           C:\prolan\ce\ComprobantesDesktop.jar
 * Qualified Name:     ec.gob.sri.comprobantes.modelo.reportes.InformacionAdicional
 * JD-Core Version:    0.6.2
 */