package ec.com.mfac;

public class Borrar {

	public static void main(String[] args) {
		String ss= "2003201801176804939000120010040000242072018203710";
		System.out.println(ss.substring(10, 23));
		System.out.println(ss.substring(24, 27));
	}

}
